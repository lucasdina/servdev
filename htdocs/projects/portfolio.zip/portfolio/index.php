<!DOCTYPE html>
<!--This websire template was created by Lucas Dina-->
<html>
	<head>
    <title>
        Jukebox
    </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
</head>



<body>
    <img id="logo" src="./images/logo.png" alt="logo" style="width: 100px;height: 100px;" />
    <div class="nav">
        <ul>
            <li class="home"><a href="index.php">Portfolio</a></li>
            <li class="about"><a href="html/about.php">Resume</a></li>
            <li class="contact"><a href="html/contact.php">Contact</a></li>
            <li class="news"><a href="html/news.php">News</a></li>
        </ul>
    </div>
    <main>
        <div id="mainText">
            <h1>Skills</h1>
            <p>After starting with C#, I realized that I did not like it at all. Since then, I have devoted my time to learning other Java and node.js. Regarding Java, I have a lot of experience with android developement and many common android libraries. My http tool of choice would be Jackson in Java, but I also have quite a bit of experience with RxJava. In node.js, I am familiar with the Express library as I have written an API with it. As for serving content, I prefer Handlebars, but I am open to learning new tools at any time.</p>
            <h1>Projects</h1>
            <p>For the most part, my personal projects revolve around mobile developement. My current app is called Jukebox (not in app stores yet). Jukebox is a music sharing app that allow people to send music to a DJ to play anywhere, whether it be in the car with friends, or even at a party. The voting system I implemented allows for users to vote for songs they like and get them moved to the top of the list. Besides that, I have an interest in automation. Creating bots for videogames has proven quite the challenge but very fun none the less.</p>
            <h1>Important Links </h1>
            
            
            <a class="links" href="https://www.linkedin.com/in/lucas-dina-010ab4134/"><img src="images/Logo-2C-128px-TM.png"></a>
            <a class="links" href="https://github.com/lucasdina/"><img src="images/GitHub_Logo.png"></a>
            <a class="links" href="https://stackoverflow.com/users/story/1568677#"><img src="images/so-logo.png"></a>
        </div>
    </main>
</body>


    
    
</html>